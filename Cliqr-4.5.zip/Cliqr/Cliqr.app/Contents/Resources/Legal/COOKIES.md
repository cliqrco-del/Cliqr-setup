# Cookie Policy

**Cliqr** · Version 2026-11-13.10 · Last updated 13 November 2026

## The short version

**The Cliqr app does not use cookies.** It also does not use tracking pixels, advertising identifiers, device fingerprinting, analytics tools or any similar technology to follow you.

## What a cookie is

A cookie is a small file that a website saves in your browser to remember you or to track you across sites. Cliqr is a Mac app, not a website, so it has no browser and does not need them.

## How Cliqr makes network requests

When Cliqr contacts an internet service (for example Open-Meteo for the weather, Google's Gemini service for AI answers, or Spotify's image servers for an album picture), it uses a private session that:

- **refuses cookies** (none are accepted or stored),
- **keeps no cache** on disk,
- sends no identifier about you or your Mac, only the information needed for the request (see the Privacy Policy).

## What Cliqr stores locally

Cliqr saves your settings, history, memory and files on your own Mac, in the app's folders and preferences. That is how a normal app remembers your choices. It is not a tracking technology, nothing in it is sent to us, and you can see and delete all of it in Settings › Privacy.

## Other companies' websites

Google, Apple, Spotify and GitHub run their own websites and apps, and those may use cookies when you visit them in a browser. That is not part of Cliqr, and their cookie policies apply.

## If we have a website

If {{DEVELOPER}} publishes a website for Cliqr, it will use only the cookies that are strictly necessary for it to work, and will ask for your consent before using any others (such as for statistics). This page will list them.

## Contact

{{CONTACT}}
