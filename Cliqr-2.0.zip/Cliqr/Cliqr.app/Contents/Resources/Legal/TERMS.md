# Terms of Service

**Cliqr** · Version 2026-11-13.8 · Last updated 13 November 2026

These terms are an agreement between you and {{DEVELOPER}} ("we", "us") about your use of the Cliqr app. By clicking "Agree" or using Cliqr you accept them. If you do not agree, do not use Cliqr.

## 1. What Cliqr is

Cliqr is a Mac assistant that lives in the notch. It listens when you ask, works with an AI that you connect yourself (Google's Gemini, with your own API key), and can look at your screen, move the mouse, type, open apps, draw, make documents and read out answers.

Cliqr is an independent project. It is **not made, endorsed or sponsored by Google, Apple, Spotify or any other company** mentioned in it. Gemini and Google are trademarks of Google LLC, and the other names belong to their owners.

## 2. Who can use Cliqr, and what you need

- **You must be 18 or older** (Google requires this to use the Gemini API), and able to enter into this agreement where you live. If you use Cliqr for an organisation, you confirm you may accept these terms for it.

- A Mac that meets the system requirements, and the macOS permissions Cliqr asks for.
- **Your own AI.** A Gemini API key from Google AI Studio. Your use of Gemini is under **Google's own terms, including the Gemini API terms and Google's prohibited use policy**. The limits and any costs of your key are yours. We do not provide, resell, share or pay for any AI service, and we never see your key, which stays in your Mac's Keychain. Google decides where the Gemini API and its free tier are available, which models you can use and what the limits are, and may change or end them at any time. On Google's free tier, Google may use what is sent to it to improve its products; read Google's current terms and use a paid key if that matters to you.
- You are responsible for keeping your API key secret and for what is done with it. If you think it has leaked, delete it in Google AI Studio and make a new one.
- Some features use other services (weather, Spotify, Google Calendar). Their own terms apply to you when you use them.

## 3. Your licence

We give you a personal, non-exclusive, non-transferable, revocable licence to install and use the Cliqr app on Macs you own or control, for your own non-commercial use. **You may not copy, modify, adapt, translate, reverse engineer, decompile, republish or redistribute Cliqr or its code, remove its notices, or sell, rent or sublicense it,** except as the law gives you a right to or as the licences of its open-source parts allow (see "Third-party software and models"). All rights not given to you are kept by us. Cliqr's source code is private and is not licensed to you. Only download Cliqr from the developer's official release page; copies from anywhere else may have been changed, and we are not responsible for them. {{LICENSE_NOTE}}

## 4. You are in control, and responsible

Cliqr can take actions on your Mac that you ask for, such as clicking, typing, opening apps and files, and creating documents. It asks you to confirm before things that are hard to undo, but **you are responsible for what you ask it to do and for checking its work.** Stop a task at any time with the Escape key or the stop button.

Do not give Cliqr passwords, payment details or other secrets. Do not leave it running tasks on a screen showing information you are not allowed to share with Google. **When Cliqr looks at your screen, what is visible (including other people's messages, documents or faces on a call) can be sent to Google as a screenshot.** You are responsible for making sure you may share it, and for closing anything private before you ask.

## 5. AI can be wrong

Gemini and Cliqr can make mistakes, mishear you, misread the screen or give out-of-date information. Answers, summaries, translations, lessons and meeting notes are for convenience. **They are not professional advice** (medical, legal, financial or otherwise). Check anything important before you rely on it.

## 6. Acceptable use

You agree not to use Cliqr to:

- break any law or anyone's rights, including privacy, copyright and recording laws;
- **record, transcribe or clone anyone's voice without their permission.** You must tell people on a call that you are taking notes where the law or courtesy requires it, and you must only clone your own voice or a voice you have the right to use;
- harm, harass, deceive or impersonate anyone;
- gain unauthorised access to computers, accounts or data;
- attack, overload or interfere with Cliqr or the services it uses, or try to get around their limits;
- use Cliqr in a way that Google's or any other provider's terms or policies forbid, or use it to build a competing product from its code or content;
- use it in situations where a mistake could cause serious harm, such as controlling medical, safety or emergency systems.

## 7. Your content and your data

You keep all rights to your content (what you say, type, create and store). You give us no rights to it, because we do not receive it. How your data is handled is described in the **Privacy Policy**, which is part of these terms.

Feedback you send us may be used to improve Cliqr, without credit or payment to you. Please don't put passwords or private information in it.

## 8. Third-party software and models

Cliqr includes or downloads open-source software and voice models that have their own licences. They are listed in **Open-source licences** (also in Settings › Privacy). That page also lists the **copyright owners and credits** for everything in Cliqr that is not ours, including voices, weather data, song lyrics, music artwork and trademarks. **Some optional voices are licensed for non-commercial use only** (including the DFKI Turkish voice and the voice-cloning model). Those licences apply to you if you use them, and you must not use those voices for a commercial purpose.

## 9. Changes, updates and availability

We may change, update or stop Cliqr or any feature, and we may change these terms. If a change matters, Cliqr will ask you to accept the new version. Cliqr depends on services we do not control (Google Gemini, macOS, Open-Meteo and others), so features may stop working without notice.

## 10. No warranty

To the fullest extent the law allows, Cliqr is provided **"as is" and "as available"**, with no promise that it will be error-free, uninterrupted, secure or fit for a particular purpose. Nothing in these terms limits rights you have by law that cannot be limited.

## 11. Limit of liability

To the fullest extent the law allows, we are not liable for indirect, incidental, special or consequential loss, or for loss of data, profit or business, arising from your use of Cliqr, including actions Cliqr takes on your Mac at your request. Our total liability for any claim is limited to the amount you paid us for Cliqr (or, if it was free, zero). We do not exclude or limit liability that cannot be excluded or limited by law, such as for death or personal injury caused by negligence, or for fraud. If you are a consumer, you keep the mandatory consumer rights of your country.

## 12. Ending

You can stop using Cliqr at any time and delete it (use "Delete everything and reset Cliqr" in Settings › Privacy first if you want your data gone). We may end your licence if you break these terms. Sections that by their nature should survive (such as 4, 5, 8, 10, 11 and 13) continue after that.

## 13. Law and disputes

These terms are governed by the laws of {{COUNTRY}}, without regard to conflict-of-law rules, except that mandatory consumer protection laws of the country where you live still apply to you. Disputes are for the courts of {{COUNTRY}}, unless the law gives you the right to go to the courts where you live.

## 14. General

- **Whole agreement.** These terms, the Privacy Policy and the open-source licences are the whole agreement between you and us about Cliqr.
- **If part is unenforceable.** If a part of these terms cannot be enforced where you live, the rest still applies.
- **No waiver.** If we do not enforce a right straight away, we have not given it up.
- **Transfer.** You may not transfer your licence to anyone else. We may transfer ours together with Cliqr.
- **Language.** If these terms are translated, the English version is the one that counts, except where the law of your country says otherwise.

## 15. Contact

{{DEVELOPER}} · {{CONTACT}}
