# Privacy Policy

**Cliqr** · Version 2026-11-13.6 · Last updated 13 November 2026

Cliqr is a Mac assistant. This policy explains what Cliqr stores, what it sends to other services, and how you can see, export and delete your data. It is written to be read.

## The short version

- Cliqr has **no accounts, no analytics, no advertising, no tracking and no cookies**.
- {{DEVELOPER}} (the developer) **does not receive your data**. Cliqr has no server of its own, so we hold nothing about you to look up or delete.
- Your conversations, memory, files and settings are stored **on your Mac**. You can see all of it, export it and delete it in **Settings › Privacy**.
- When you ask Cliqr to do something, your request is sent to **the AI you connected**: **Google's Gemini**, using your own key. A few features contact other services (listed below), and only when you use them.
- Cliqr **never accesses your Google account, name, email or contacts.** It only uses a Gemini API key that you paste in yourself.

## Who is responsible

{{DEVELOPER}} provides the Cliqr app. For the data that stays on your Mac, you are in control of it. The services listed in "What leaves your Mac" are run by other companies, each responsible for its own handling of your data under its own privacy policy.

Contact for privacy questions: {{CONTACT}}

## What Cliqr stores on your Mac

All of this is stored in your user account on your Mac. Nothing here is uploaded by Cliqr.

- **Conversation history**: the text of your requests, the AI's replies and short notes of the actions taken. Folder: `~/Library/Application Support/Cliqr/history`. You choose whether it is saved and for how long (default: 30 days).
- **Memory**: facts you asked Cliqr to remember, in `~/Library/Application Support/Cliqr/memory.md`. You can read, edit and delete every item in Settings › Memory.
- **Files Cliqr makes**: PDFs and meeting transcripts shown on the notch's Files shelf, in `~/Library/Application Support/Cliqr/Created`. They are removed when you take them off the shelf or after the retention period.
- **Voice samples**: if you add a voice for voice cloning, the audio sample you provide stays in `~/Library/Application Support/Cliqr/voices`.
- **Screenshots**: when Gemini needs to see your screen, a screenshot is saved to `~/Library/Caches/Cliqr/screens` so it can be sent to Google. These are deleted automatically within minutes and when Cliqr quits.
- **A technical log**: `~/Library/Logs/Cliqr.log` records events such as "voice started" or errors. It does not contain what you said or what the AI replied. It is limited to 2 MB.
- **Your Gemini API key** (only if you use Google's AI): stored in your Mac's Keychain, on this device only. It is never written to a file, never part of exports, and removed by "Delete everything and reset Cliqr" or the "Remove key" button.
- **Settings**: your preferences, including the city you typed for the weather, the routines you made, the apps pinned to the dock, and a Google Calendar secret address if you add one. Cliqr also stores when you accepted these documents.
- **Downloaded voice models**: speech models you download. They contain no personal data.


## What leaves your Mac

Cliqr contacts these services only when the feature that needs them is used. It does not use cookies or a cache for these requests.

- **Google (Gemini).** Your request is sent to Google's Gemini service at `generativelanguage.googleapis.com` together with your API key (in a request header, not in the web address). This includes your typed or spoken request (your speech is turned into text on your Mac first), screenshots when Gemini looks at your screen, notes from Memory, text you copy for it, and meeting transcripts you ask it to summarize. Cliqr uses your key only to talk to Gemini; it does not sign in to your Google account and cannot see it. Google handles what it receives under its own terms and privacy policy. **On Google's free tier, Google may use content to improve its products, so use a paid key for anything private**, and read Google's current terms.
- **Open-Meteo (weather).** Rounded coordinates (about one kilometre) of your location, or the city name you typed, to get the forecast. No account or identifier is sent.
- **Apple.** Your Mac's Location Services can supply your position for the weather, and Apple's service may turn it into a place name. Speech recognition runs with Apple's speech models on your Mac; if you use the older recognition mode, Apple may process audio on its servers as described in Apple's privacy information.
- **Spotify.** Cliqr reads the song that the Spotify app on your Mac is playing, locally. To show the album picture it requests the image from Spotify's image servers, which can see your internet address.
- **Google Calendar.** Only if you paste a "secret address in iCal format". Cliqr fetches that address to read your events. Treat that address like a password.
- **LRCLIB (lyrics).** Only if "Show lyrics" is on and Spotify is playing: the song's title, artist, album and length are sent to lrclib.net to look up its lyrics, and LRCLIB can see your internet address. Lyrics are shown while the song plays and are not saved. You can turn this off in Settings › General.
- **GitHub.** Only when you press a button to download a voice model. GitHub can see your internet address.

Cliqr does not send anything else, and it does not include crash reporting or usage statistics.

## Permissions

Cliqr asks macOS for permissions only for what you use. You can turn each off in System Settings › Privacy & Security.

- **Microphone**: to hear you while you hold Control + Option (or, if you turn it on, for the wake word). Audio is turned into text on your Mac and is not saved.
- **Input Monitoring**: only to notice the Control + Option keys. Cliqr does not record what you type.
- **Accessibility**: to move the mouse and type when you ask it to. It acts only while a request is running.
- **Screen Recording**: to take screenshots, draw on your screen, hear the other side of a call for meeting notes, and measure how loud the music is so the bars next to the notch can move with it. For the music bars, only loudness levels are measured; the sound is not recorded, saved or sent anywhere.
- **Calendar and Location**: for meeting reminders and local weather. Both optional.
- **Automation (Spotify, System Events)**: to read and control Spotify and to switch dark mode.

## Meeting notes and other people's voices

If you use meeting notes, Cliqr records your microphone and the sound of the call and turns it into text on your Mac. The recording itself is not saved, only the transcript. **You are responsible for telling the other people that you are taking notes, and for following the recording laws that apply to you.** The transcript is sent to Gemini only if you ask for notes.

## Voice cloning

If you add a voice from a recording, Cliqr copies its sound on your Mac. Only use recordings of yourself or of people who agreed, and see the Terms of Service.

## How long we keep things

Cliqr keeps data on your Mac until you delete it, except where you set a limit: conversation history and files Cliqr makes are deleted after the period you choose in Settings › Privacy (default 30 days), screenshots after minutes, and the log at 2 MB. We keep no data ourselves.

## Your rights and your choices

Wherever you live, you can use the tools in **Settings › Privacy** to:

- see what Cliqr stores and how big it is,
- **export** your data (history, memory and settings) to a file,
- **delete** any part of it, or **delete everything and reset Cliqr**,
- turn off saving history, and set how long things are kept.

Depending on where you live (for example the EU and UK under the GDPR, Türkiye under Law No. 6698 (KVKK), California under the CCPA), you also have rights to access, correct, delete, restrict, object to and move your data. Because we hold no data about you, these are fulfilled by the tools above. To exercise a right with a company that does hold your data (such as Google, Anthropic, Apple or Spotify), contact that company. You can also ask us a privacy question at {{CONTACT}}, and you can complain to your local data protection authority.

Cliqr does not sell your data and does not make decisions about you by automated means that have legal or similarly significant effects.

## Legal grounds (EU, UK and similar)

Cliqr processes data on your device because you ask it to (to provide the features you use) and, where required, with your consent through the macOS permission prompts and your choices in Settings. Data goes to other services only to carry out your request.

## International transfers

Google, Apple, Open-Meteo, LRCLIB, Spotify and GitHub may process data in countries other than yours. See their privacy policies for how they protect it.

## Security

Your data stays in your user account, protected by your Mac's own protections. We recommend turning on FileVault and a login password. A Google Calendar secret address is kept in the app's preferences, so do not share your Mac account.

## Children

Cliqr is not meant for anyone under 18 (the Gemini API it uses requires this), and we do not knowingly collect children's data.

## Changes

If this policy changes in a way that matters, Cliqr will ask you to review it again before continuing. The version and date are at the top.

## Contact

{{DEVELOPER}} · {{CONTACT}} · {{COUNTRY}}
